import Link from "next/link";

const vps = [
  {name:"SKN-VPS-01", type:"KVM", ip:"103.xx.xx.xx", status:"Running", cpu:"2 vCPU", ram:"4 GB", disk:"40 GB"},
  {name:"SKN-VPS-02", type:"SSH VPS", ip:"IPv6 only", status:"Stopped", cpu:"1 vCPU", ram:"2 GB", disk:"20 GB"}
];

export default function Home() {
  return <main className="shell">
    <aside>
      <div className="brand">SKYLER<span>NODES</span><small>KVM CLOUD</small></div>
      <nav>
        <Link href="/">Dashboard</Link>
        <Link href="/vps">VPS Management</Link>
        <Link href="/create">Create VPS</Link>
        <Link href="/console">Console</Link>
        <Link href="/network">Network & Ports</Link>
        <Link href="/os">OS Images</Link>
        <Link href="/admin">Admin Panel</Link>
      </nav>
      <div className="userbox">Anik<br/><small>Administrator</small></div>
    </aside>
    <section className="content">
      <header><div><p className="eyebrow">KVM / SSH CLOUD</p><h1>Dashboard</h1></div><Link className="button" href="/create">+ Create VPS</Link></header>
      <div className="cards">
        <Card title="Total VPS" value="12"/><Card title="Running" value="8"/><Card title="IPv4 Available" value="6"/><Card title="Nodes Online" value="2"/>
      </div>
      <div className="panel"><div className="panelhead"><h2>Your VPS</h2><Link href="/vps">View all</Link></div>
        {vps.map(x=><div className="vps" key={x.name}><div><b>{x.name}</b><small>{x.type} · {x.ip}</small></div><span className={x.status==="Running"?"ok":"off"}>{x.status}</span><div>{x.cpu}</div><div>{x.ram}</div><div>{x.disk}</div><Link className="mini" href="/console">Console</Link></div>)}
      </div>
    </section>
  </main>
}
function Card({title,value}) { return <div className="card"><small>{title}</small><strong>{value}</strong></div> }

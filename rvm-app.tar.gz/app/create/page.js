export default function Create() {
 return <main className="formpage"><a href="/">← Dashboard</a><h1>Create Virtual Machine</h1>
 <div className="form">
  <label>VPS Name<input placeholder="skn-vps-01"/></label>
  <label>VPS Type<select><option>KVM VPS</option><option>SSH VPS</option><option>No-IP VPS</option></select></label>
  <label>Node<select><option>SKN-IN-01</option><option>SKN-IN-02</option></select></label>
  <label>Operating System<select><option>Ubuntu 24.04 LTS</option><option>Ubuntu 22.04 LTS</option><option>Debian 13</option><option>Debian 12</option><option>Rocky Linux 10</option><option>AlmaLinux 10</option><option>Fedora</option><option>Arch Linux</option><option>openSUSE</option><option>Windows Server</option></select></label>
  <div className="grid"><label>CPU<input type="number" defaultValue="2"/></label><label>RAM MB<input type="number" defaultValue="4096"/></label><label>Disk GB<input type="number" defaultValue="40"/></label></div>
  <label>IPv4<select><option>Auto Assign</option><option>Disable IPv4</option></select></label>
  <label>IPv6<select><option>Enable IPv6</option><option>Disable IPv6</option></select></label>
  <label>SSH Port<input type="number" defaultValue="22"/></label>
  <button>Create VPS</button>
 </div></main>
}
